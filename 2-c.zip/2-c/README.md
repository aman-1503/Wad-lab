# WADL
Web application development laboratory assignments repository.
